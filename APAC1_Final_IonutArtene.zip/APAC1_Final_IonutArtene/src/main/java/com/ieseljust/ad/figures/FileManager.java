package com.ieseljust.ad.figures;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

class FileManager {

    public FileManager() {

    }

    private boolean validaInt(String s) {
        try {
            Integer.parseInt(s);
        } catch (NumberFormatException | NullPointerException e) {
            return false;
        }
        // only got here if we didn't return false
        return true;
    }

    public Boolean Exists(String file) {
        File f = new File(file);
        return f.exists();

    }

    public Escena importFromText(String file) {
        Escena escena = null;
        if (Exists(file)) {

            FileReader fr = null;
            BufferedReader bfr = null;

            try {
                escena = new Escena();
                File f = new File(file);

                fr = new FileReader(f);
                bfr = new BufferedReader(fr);

                while (bfr.ready()) {
                    String linea = bfr.readLine();
                    String[] items = linea.split(" ");
                    switch (items[0]) {
                        case "dimensions" ->
                            escena.dimensions(Integer.parseInt(items[1]), Integer.parseInt(items[2]));
                        case "rectangle" -> {
                            // Si tot és correcte creem la figura cercle
                            Rectangle nouRect = new Rectangle(Integer.parseInt((items[1])),
                                    Integer.parseInt((items[2])), Integer.parseInt((items[3])),
                                    Integer.parseInt((items[4])), items[5]);
                            // I l'afegim a la llista
                            escena.add(nouRect);
                        }
                        case "cercle" -> {
                            // Si tot és correcte creem la figura cercle
                            Cercle nouCer = new Cercle(Integer.parseInt((items[1])), Integer.parseInt((items[2])),
                                    Integer.parseInt((items[3])), items[4]);
                            // I l'afegim a la llista
                            escena.add(nouCer);
                        }
                        case "linia" -> {
                            Linia nouLini = new Linia(Integer.parseInt((items[1])), Integer.parseInt((items[2])),
                                    Integer.parseInt((items[3])), Integer.parseInt((items[4])), items[5]);

                            // I l'afegim a la llista
                            escena.add(nouLini);
                        }

                    }

                }

            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (NumberFormatException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } finally {
                try {
                    fr.close();
                    bfr.close();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }

            return escena;
        }
        return escena;

    }

    public Escena importFromObj(String file) {
        Escena escena = new Escena();
        try {
            File f = new File(file);
            FileInputStream fr = new FileInputStream(f);

            ObjectInputStream datos = new ObjectInputStream(fr);
            int x=(Integer)datos.readObject();
            int y=(Integer)datos.readObject();
            escena.dimensions(x, y);
            while (fr.available() > 0) {
                Figura f3 = (Figura) datos.readObject();
                escena.add(f3);
            }

            datos.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return escena;

    }

    public Boolean exportText(Escena escena, String file) {

        FileWriter fw = null;
        BufferedWriter bw = null;
        try {
            fw = new FileWriter(file, true);
            bw = new BufferedWriter(fw);
            bw.write("dimensions " + escena.getX() + " " + escena.getY());
            bw.newLine();

        } catch (IOException ex) {

        } finally {
            try {
                bw.close();
                fw.close();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        List<Figura> figuras = escena.LlistaFigures;
        for (Figura fig : figuras) {

            fig.getAsText(fig, file);

        }
        return true;

    }

    public Boolean exportObj(Escena escena, String file) {

        File f = new File(file);
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try {
            fos = new FileOutputStream(f, true);
            oos = new ObjectOutputStream(fos);
            oos.writeObject(escena.getX());
            oos.writeObject(escena.getY());
            for (Figura f2 : escena.LlistaFigures) {

                oos.writeObject(f2);
            }
            oos.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (FileNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        return true;

    }

    public Boolean exportSVG(Escena escena, String file) {
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();

            Element arrel = doc.createElement("svg");
            arrel.setAttribute("height", String.valueOf(escena.getX()));
            arrel.setAttribute("width", String.valueOf(escena.getY()));
            doc.appendChild(arrel);
            List<Figura> figuras = escena.LlistaFigures;
            for (Figura f : figuras) {

                arrel.appendChild(f.getAsXml(f, doc));

            }

            Transformer trans = TransformerFactory.newInstance().newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new FileOutputStream(file));

            trans.transform(source, result);

        } catch (ParserConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerConfigurationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerFactoryConfigurationError e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (TransformerException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return true;

    }

    public Boolean exportJSON(Escena escena, String filename) {

        try {

            JSONObject esce = new JSONObject();
            esce.put("height", escena.getX());
            esce.put("width", escena.getY());
            JSONArray figura;
            figura = new JSONArray();

            escena.LlistaFigures.forEach(m -> {

                figura.put(m.getAsJson());

            });
            esce.put("figuras", figura);

            JSONObject arrel = new JSONObject();

            arrel.put("escena", esce);

            try (FileWriter file = new FileWriter(filename)) {
                file.write(arrel.toString(4)); // 4 són els espais d'indentació
            } // 4 són els espais d'indentació

        } catch (JSONException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
        }

        return true;

    }

}
